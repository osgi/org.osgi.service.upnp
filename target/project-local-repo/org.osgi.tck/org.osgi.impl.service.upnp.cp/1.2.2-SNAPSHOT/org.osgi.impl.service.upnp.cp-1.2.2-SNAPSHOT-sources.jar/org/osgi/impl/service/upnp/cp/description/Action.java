/*******************************************************************************
 * Copyright (c) Contributors to the Eclipse Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * SPDX-License-Identifier: Apache-2.0 
 *******************************************************************************/
package org.osgi.impl.service.upnp.cp.description;

public class Action {
	private String			name;
	private ArgumentList	args[];

	// This method returns the name of the action.
	public String getName() {
		return name;
	}

	// This method returns the arguments of the action.
	public ArgumentList[] getArguments() {
		if (args == null) {
			return new ArgumentList[0];
		}
		return args;
	}

	// This method sets the name for the action.
	public void setName(String nam) {
		name = nam;
	}

	// This method sets the argument lists for the action.
	public void setArgumentList(ArgumentList al[]) {
		args = al;
	}
}